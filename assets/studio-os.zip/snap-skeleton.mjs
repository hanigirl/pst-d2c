import { chromium } from 'playwright';
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1.5 });
const page = await ctx.newPage();
const routes = [
  { url: 'http://localhost:3001/studioOS',         out: '/tmp/skel-dashboard.png' },
  { url: 'http://localhost:3001/studioOS/projects', out: '/tmp/skel-projects.png' },
  { url: 'http://localhost:3001/studioOS/tasks',    out: '/tmp/skel-tasks.png' },
  { url: 'http://localhost:3001/studioOS/team',     out: '/tmp/skel-team.png' },
];
for (const r of routes) {
  await page.goto(r.url, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(400);
  await page.screenshot({ path: r.out, fullPage: false });
  console.log(`  saved ${r.out}`);
}
await browser.close();
