import { chromium } from 'playwright';
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1024 }, deviceScaleFactor: 2 });
const page = await ctx.newPage();
await page.goto('http://localhost:3001/studioOS/tasks', { waitUntil: 'networkidle', timeout: 30000 });
await page.waitForTimeout(800);
await page.screenshot({ path: '/tmp/tasks-live.png', fullPage: true });
await browser.close();
console.log('saved /tmp/tasks-live.png');
